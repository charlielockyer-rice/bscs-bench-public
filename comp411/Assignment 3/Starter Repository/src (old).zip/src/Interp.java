/** Nine different interpreters for Jam that differ in binding policy and cons evaluation policy.
  * The binding policy is either: call-by-value, call-by-name, or call-by-need.
  * The cons evaluation policy is either: call-by-value (eager), call-by-name (redundant lazy), or
  * call-by-need (efficient lazy).
  */

import java.io.IOException;
import java.io.Reader;


/** The exception class for Jam run-time errors during program evaluation. */
class EvalException extends RuntimeException {
  EvalException(String msg) { super(msg); }
}

/** Interpreter class supporting nine forms of evaluation for Jam programs.  These forms of evaluation differ in
  * binding policy and cons evaluation policy.
  * The binding policy is either: call-by-value, call-by-name, or call-by-need.
  * The cons evaluation policy is either: call-by-value (eager), call-by-name (redundant lazy), or
  * call-by-need (efficient lazy). */
class Interpreter {
  /** Parser to use. */
  Parser parser;  // initialized in constructors
  
  /** Parsed AST. */
  AST prog;       // initialized in constructors
  
  Interpreter(String fileName) throws IOException {
    parser = new Parser(fileName);
    prog = parser.parseAndCheck();
  }
  
  Interpreter(Parser p) {
    parser = p;
    prog = parser.parseAndCheck();
  }
  
  Interpreter(Reader reader) {
    parser = new Parser(reader);
    prog = parser.parseAndCheck();
  }
  
  /* Interpreter API: the public methods of this Jam Interpreter */
  
  /** Parses and ValueValue interprets the input embeded in parser, returning the result. */
  public JamVal callByValue() { return prog.accept(valueValueVisitor); }
  
  /** Parses and NameValue interprets the input embeded in parser, returning the result. */
  public JamVal callByName() { return prog.accept(nameValueVisitor); }
  
  /** Parses and NeedValue interprets the input embeded in parser, returning the result. */
  public JamVal callByNeed() { return prog.accept(needValueVisitor); }
  
  /** Parses and ValueValue interprets the input embeded in parser, returning the result. */
  public JamVal valueValue() { return prog.accept(valueValueVisitor); }
  
  /** Parses and ValueName interprets the input embeded in parser, returning the result. */
  public JamVal valueName() { return prog.accept(valueNameVisitor); }
  
  /** Parses and ValueNeed interprets the input embeded in parser, returning the result. */
  public JamVal valueNeed() {return prog.accept(valueNeedVisitor); }
  
  /** Parses and NameValue interprets the input embeded in parser, returning the result.  */
  public JamVal nameValue() { return prog.accept(nameValueVisitor); }
  
  /** Parses and NameName interprets the input embeded in parser, returning the result. */
  public JamVal nameName() { return prog.accept(nameNameVisitor); }
  
  /** Parses and NameNeed interprets the input embeded in parser, returning the result. */
  public JamVal nameNeed() { return prog.accept(nameNeedVisitor); }
  
  /** Parses and NeedValue interprets the input embeded in parser, returning the result. */
  public JamVal needValue() { return prog.accept(needValueVisitor); }
  
  /** Parses and NeedName interprets the input embeded in parser, returning the result. */
  public JamVal needName() { return prog.accept(needNameVisitor); }
  
  /** Parses and NeedNeed interprets the input embeded in parser, returning the result. */
  public JamVal needNeed() { return prog.accept(needNeedVisitor); }
  
  
  /* Interfaces that support different forms of Binding and different forms of list construction */
  
  /** The interface supported by various binding evaluation policies: call-by-value, call-by-name, and call-by-need. */
  interface BindingPolicy {  // formerly called EvalPolicy
    
    /** Constructs the appropriate binding object for this, binding var to ast in the evaluator ev. */
    Binding newBinding(Variable var, AST ast, EvalVisitor ev);
    
    /** Constructs the appropriate dummy binding object for this. */
    Binding newDummyBinding(Variable var);
  }
  
  /** Interface containing a factory to build the cons object specified by this ConsPolicy. */
  interface ConsPolicy {
    /** Constructs the appropriate cons given the arguments and corresponding EvalVisitor. */
    JamVal evalCons(AST[] args, EvalVisitor ev);
  }
  
  /* Note: Binding is defined in the file ValuesTokens because the JamClosure class depends on it. */
  
  /** Class representing a binding in CBV evaluation. */ 
  static abstract /* ... abstract modifier must be omitted in your code */ class ValueBinding extends Binding {
    /* ... Your code goes here */
    public ValueBinding(/* your parameters go here */) { /* ... Your code replaces */ super(null, null); }
    public String toString() { return "[" + var + ", " + value + "]"; }
  }
  
  /** Class representing a binding in CBName evaluation. The inherited value field is ignored. */
  static  abstract /* ... abstract modifier must be omitted in your code */ class NameBinding extends Binding {
    protected Suspension susp;
    /* ... Your code goes here */
    public NameBinding(/* ... your parameters go here */) { /* ... Your code replaces */ super(null, null); }
    public String toString() { return "[" + var + ", " + susp + "]"; }
  }
  
  /** Class representing a binding in CBNeed evaluation.  The inherited value field is used to hold the value
    * first computed by need .. */
  static  abstract /* ... abstract modifier must be omitted in your code */ class NeedBinding extends NameBinding {
    /* ... Your code goes here  */
    public NeedBinding(/* ... your parameters go here */) { /* ... Your code goes here */ }
    public String toString() { return "[" + var + ", " + value + ", " + susp + "]"; }
  }
  
  /** Helper method supporting Binding classes */
  static JamVal illegalForwardReference(Variable v) {
    throw new EvalException("Attempt to evaluate variable " + v + " bound to null, indicating an illegal forward reference");
  }
  
  /** Binding policy for call-by-value. */
  static final BindingPolicy CALL_BY_VALUE = new BindingPolicy() {
    public Binding newBinding(Variable var, AST arg, EvalVisitor ev) { /* ... Your code replaces */ return null; }
    public Binding newDummyBinding(Variable var) { /* ... Your code replaces */ return null; } 
  };
  
  /** Binding policy for call-by-name. */
  static final BindingPolicy CALL_BY_NAME = new BindingPolicy() {
    public Binding newBinding(Variable var, AST arg, EvalVisitor ev) { /* ... Your code replaces */ return null; }
    public Binding newDummyBinding(Variable var) { /* ... Your code replaces */ return null; }
  };
  
  /** Binding policy for call-by-need. */
  static final BindingPolicy CALL_BY_NEED = new BindingPolicy() {
    public Binding newBinding(Variable var, AST arg, EvalVisitor ev) { /* ... Your code replaces */ return null; }
    public Binding newDummyBinding(Variable var) { /* ... Your code replaces */ return null; }
  };
  
  /** A class representing an AST paired with the corresponding evaluator. */
  static abstract /* ... abstract modifier must be omitted in your code */ class ConcreteSuspension implements Suspension {
    private AST exp;
    private EvalVisitor ev; 
    /* ... Your code goes here */
    public String toString() { return "<" + exp + ", " + ev + ">"; }
  }
  
  static class Trivial {}
  
  /** Class for a lazy cons structure. */
  static class JamLazyNameCons extends JamCons {
    /** Suspension for first */
    protected Suspension firstSusp;
    /** Suspension for rest */
    protected Suspension restSusp;
    public JamLazyNameCons(/* ... your parameters go here*/) { /* ... Your code replaces */ super(null, null); }
    
    /* ... Your code goes here. */
  }
  
  /** Class for a lazy cons with optimization. */
  static class JamLazyNeedCons extends JamLazyNameCons {
    /* ... Your field declarations go here. */
    
    public JamLazyNeedCons(/* ... your parameters go here*/) { /* ... Your code goes here */ }
    
    /* ... Your code goes here */
  }
  
  /** Eager cons evaluation policy. presume that args has exactly 2 elements. */
  public static final ConsPolicy EAGER = new ConsPolicy() {
    public JamVal evalCons(AST[] args, EvalVisitor ev) { /* ... Your code replaces */ return null; }
  };
  
  /** Call-by-name lazy cons evaluation policy. */
  public static final ConsPolicy LAZYNAME = new ConsPolicy() {
    public JamVal evalCons(AST[] args, EvalVisitor ev) { /* ... Your code replaces */ return null; }
  };
  
  /** Call-by-need lazy cons evaluation policy. */
  public static final ConsPolicy LAZYNEED = new ConsPolicy() {
    public JamVal evalCons(AST[] args, EvalVisitor ev) { /* ... Your code replaces */ return null; }
  };
  
  /** Value-value visitor. */
  static final ASTVisitor<JamVal> valueValueVisitor = new EvalVisitor(CALL_BY_VALUE, EAGER);
  
  /** Value-name visitor. */
  static final ASTVisitor<JamVal> valueNameVisitor = new EvalVisitor(CALL_BY_VALUE, LAZYNAME);
  
  /** Value-need visitor. */
  static final ASTVisitor<JamVal> valueNeedVisitor = new EvalVisitor(CALL_BY_VALUE, LAZYNEED);
  
  /** Name-value visitor. */
  static final ASTVisitor<JamVal> nameValueVisitor = new EvalVisitor(CALL_BY_NAME, EAGER);
  
  /** Name-name visitor. */
  static final ASTVisitor<JamVal> nameNameVisitor = new EvalVisitor(CALL_BY_NAME, LAZYNAME);
  
  /** Name-need visitor. */
  static final ASTVisitor<JamVal> nameNeedVisitor = new EvalVisitor(CALL_BY_NAME, LAZYNEED);
  
  /** Need-value visitor. */
  static final ASTVisitor<JamVal> needValueVisitor = new EvalVisitor(CALL_BY_NEED, EAGER);
  
  /** Need-name visitor. */
  static final ASTVisitor<JamVal> needNameVisitor = new EvalVisitor(CALL_BY_NEED, LAZYNAME);
  
  /** Need-need visitor. */
  static final ASTVisitor<JamVal> needNeedVisitor = new EvalVisitor(CALL_BY_NEED, LAZYNEED);
  
  
  /** Primary visitor class for performing interpretation. */
  static class EvalVisitor implements ASTVisitor<JamVal> {
    
    /* Assumes that:
     *   OpTokens are unique
     *   Variable objects are unique: v1.name.equals(v.name) => v1 == v2
     *   Only objects used as boolean values are BoolConstant.TRUE and BoolConstant.FALSE
     * Hence, == can be used to compare Variable objects, OpTokens, and BoolConstants
     */
    
    /** Environment. */
    PureList<Binding> env;
    
    /** Policy to create bindings. */
    BindingPolicy bindingPolicy;
    
    /** Policy to create cons. */
    ConsPolicy consPolicy;
    
    private EvalVisitor(PureList<Binding> e, BindingPolicy bp, ConsPolicy cp) {
      env = e;
      bindingPolicy = bp;
      consPolicy = cp;
    }
    
    public EvalVisitor(BindingPolicy bp, ConsPolicy cp) { this(new Empty<Binding>(), bp, cp); }
    
    public JamVal forBoolConstant(BoolConstant b) { return b; }
    public JamVal forIntConstant(IntConstant i) { return i; }
    public JamVal forEmptyConstant(EmptyConstant n) { return JamEmpty.ONLY; }
    public JamVal forVariable(Variable v) { /* ... Your code replaces */ return null; }
    public JamVal forPrimFun(PrimFun f) { return f; }
    
    public JamVal forUnOpApp(UnOpApp u) { return u.rator().accept(new UnOpEvaluator(u.arg().accept(this))); }
    public JamVal forBinOpApp(BinOpApp b) { return b.rator().accept(new BinOpEvaluator(b.arg1(), b.arg2())); }
    public JamVal forApp(App a) { /* ... Your code replaces */ return null; } 
    
    public JamVal forMap(Map m) { /* ... Your code replaces */ return null; } 
    public JamVal forIf(If i) { /* ... Your code replaces */ return null; }
    
    /* Recursive let semantics */
    public JamVal forLet(Let l) { /* ... Your code replaces */ return null; } 
    
    /* ... Your code goes here */
    
    /* Inner classes */
    
    /** Evaluates the application of a function to an array of argument ASTs. A true inner class that accesses the enclosing 
      * EvalVisitor instance. The applied function may be a JamClosure or a PrimFun. Note: this class replaces StandardFun*/
    class FunEvaluator implements JamFunVisitor<JamVal> {
     
      /* ... Your code goes here */

      /** The anonymous inner class that evaluates PrimFun applications.  The evaluation of arguments must be deferred
        * in the evaluation of lazy cons. As a result, the evalArgs() method is called in all of the forXXXX methods
        * except forCons, adding lines of code that were not present in Project 2.  Note: this anonymous inner class 
        * replaces StandardPrimFunVisior in the solution to Assignment 2.  Perhaps, it should be written as a revision 
        * of StandardPrimFunVisitor.  Only the evaluation of cons is different. */
      PrimFunVisitor<JamVal> primEvaluator = new PrimFunVisitor<JamVal>() {
        /** ... Your private methods, if any go here */
        
        public JamVal forFunctionPPrim() { /* ... Your code replaces */ return null; }
        public JamVal forNumberPPrim() {/* ... Your code replaces */ return null; }
        public JamVal forListPPrim() {/* ... Your code replaces */ return null; }
        public JamVal forConsPPrim() {/* ... Your code replaces */ return null; }
        public JamVal forEmptyPPrim() {/* ... Your code replaces */ return null; }
        public JamVal forArityPrim() {/* ... Your code replaces */ return null; }
        public JamVal forConsPrim() {/* ... Your code replaces */ return null; }
        public JamVal forFirstPrim() {/* ... Your code replaces */ return null; } 
        public JamVal forRestPrim() {/* ... Your code replaces */ return null; } 
      };  
      
      /* Support for JamFunVisitor<JamVal> interface */
      
      /* Evaluates the closure application. */
      public JamVal forJamClosure(JamClosure closure) { /* ... Your code replaces */ return null; }
      
      /* Evaluates the primFun application.  The arguments cannot be evaluated yet because cons may be lazy. */
      public JamVal forPrimFun(PrimFun primFun) { /* ... Your code replaces */ return null; }
    }
    
    /** Evaluator for unary operators. Operand is already value (JamVal). */
    static class UnOpEvaluator implements UnOpVisitor<JamVal> {
      /** Value of the operand. */
      private JamVal val;
      
      UnOpEvaluator(JamVal jv) { val = jv; }
      
      /** Returns the value of the operand if it is an IntConstant; otherwise throws an exception. */
      private IntConstant checkInteger(String op) {
        if (val instanceof IntConstant)  return (IntConstant)val;
        throw new EvalException("Unary operator `" + op + "' applied to non-integer " + val);
      }
      
      /** Returns the value of the operand if it is a BoolConstant; otherwise throws an exception. */
      private BoolConstant checkBoolean(String op) {
        if (val instanceof BoolConstant)  return (BoolConstant)val;
        throw new EvalException("Unary operator `" + op + "' applied to non-boolean " + val);
      }
      
      /* Visitor methods in UnOpVisitor<JamVal> interface */
      public JamVal forUnOpPlus() { return checkInteger("+"); }
      public JamVal forUnOpMinus() { return new IntConstant(-checkInteger("-").value()); }
      public JamVal forOpTilde() { return checkBoolean("~").not(); }
    }
    
    /** Evaluator for binary operators. A true inner class that references the enclosing EvalVisior*/
    class BinOpEvaluator implements BinOpVisitor<JamVal> {
      /** Unevaluated arguments. */
      private AST arg1, arg2;
      
      BinOpEvaluator(AST a1, AST a2) {
        arg1 = a1;
        arg2 = a2;
      }
      
      /** Returns the value of arg if it is an IntConstant; otherwise throw an exception, */
      private IntConstant evalIntegerArg(AST arg, String b) {
        JamVal val = arg.accept(EvalVisitor.this);
        if (val instanceof IntConstant)  return (IntConstant)val;
        throw new EvalException("Binary operator `" + b + "' applied to non-integer " + val);
      }
      
      /** Returns the value of the argument if it is a BoolConstant, otherwise throw an exception, */
      private BoolConstant evalBooleanArg(AST arg, String b) {
        JamVal val = arg.accept(EvalVisitor.this);
        if (val instanceof BoolConstant)  return (BoolConstant)val;
        throw new EvalException("Binary operator `" + b + "' applied to non-boolean " + val);
      }
      
      /* Visitor methods */
      public JamVal forBinOpPlus() {
        return new IntConstant(evalIntegerArg(arg1,"+").value() + evalIntegerArg(arg2, "+").value());
      }
      
      public JamVal forBinOpMinus() {
        return new IntConstant(evalIntegerArg(arg1,"-").value() - evalIntegerArg(arg2, "-").value());
      }
      
      public JamVal forOpTimes() {
        return new IntConstant(evalIntegerArg(arg1,"*").value() * evalIntegerArg(arg2, "*").value());
      }
      
      public JamVal forOpDivide() {
        int divisor = evalIntegerArg(arg2, "/").value();
        if (divisor == 0) {
          throw new EvalException("Attempt to divide by zero");
        }
        return new IntConstant(evalIntegerArg(arg1,"/").value() / divisor);
      }
      
      public JamVal forOpEquals() {
        return BoolConstant.toBoolConstant(arg1.accept(EvalVisitor.this).equals(arg2.accept(EvalVisitor.this)));
      }
      
      public JamVal forOpNotEquals() {
        return BoolConstant.toBoolConstant(!arg1.accept(EvalVisitor.this).equals(arg2.accept(EvalVisitor.this)));
      }
      
      public JamVal forOpLessThan() {
        return BoolConstant.toBoolConstant(evalIntegerArg(arg1, "<").value() < evalIntegerArg(arg2, "<").value());
      }
      
      public JamVal forOpGreaterThan() {
        return BoolConstant.toBoolConstant(evalIntegerArg(arg1, ">").value() > evalIntegerArg(arg2, ">").value());
      }
      
      public JamVal forOpLessThanEquals() {
        return BoolConstant.toBoolConstant(evalIntegerArg(arg1, "<=").value() <= evalIntegerArg(arg2, "<=").value());
      }
      
      public JamVal forOpGreaterThanEquals() {
        return BoolConstant.toBoolConstant(evalIntegerArg(arg1, ">=").value() >= evalIntegerArg(arg2, ">=").value());
      }
      
      public JamVal forOpAnd() {
        BoolConstant b1 = evalBooleanArg(arg1, "&");
        if (b1 == BoolConstant.FALSE)  return BoolConstant.FALSE;
        return evalBooleanArg(arg2, "&");
      }
      
      public JamVal forOpOr() {
        BoolConstant b1 = evalBooleanArg(arg1, "|");
        if (b1 == BoolConstant.TRUE) return BoolConstant.TRUE;
        return evalBooleanArg(arg2, "|");
      }
    } // end of BinOpEvaluator class
  } // end of EvalVisitor class
} // end of Interpreter class
